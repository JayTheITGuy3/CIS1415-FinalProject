"""
Program: CIS1415_FinalProject_JeremyHinz.py
Author: Jeremy Hinz
Created: November 30, 2020
Last Modified: December 6, 2020

Purpose: To calculate the weight of a package and determine what size box is needed

Analysis: Bottles come in three sizes. Large, medium, and small.
The standard packing unit is based of the large bottles.

Design: Check flowchart and proposal notes
"""

from breezypythongui import *
from datetime import *
from tkinter import PhotoImage


class Calculator(EasyFrame):

    def __init__(self):

        EasyFrame.__init__(self, width=800, height=500, title="Bottle Weight & Shipping Calculator")
        self.setResizable(False)

        # Default Properties that are used with all products
        self.weight = 0.0  # Keeps track of current weight for order
        self.totalItems = 0  # Keeps track of total items
        self.packageSize = 0  # Keeps tracking of packing units to know what box to use
        self.textLines = []  # Keep a list record of all the items added or removed to help print out later
        # Dictionary on the different box sizes used
        self.packageDescription = {"6pack": "6-Pack Needed                              ",
                                   "12pack": "12-Pack Needed                            ",
                                   "18pack": "18-Pack Needed                             ",
                                   "32pack": "32-Pack Needed                              ",
                                   "overage": "Overage - Please divide order                ",
                                   "zero": "No items are in the bin                          ",}
        self.unitSize = {"small": 0.6666, "medium": 0.8, "large": 1.0}  # Dictionary on the three different bottle sizes
        self.formatWeightForString = 0.0  # Used to make the weight for string conversion global on a module level
        self.formatPackageSizeForString = 0.0  # Used as a module level access for package to string conversion

        # Keeps track of individual items, making sure there isn't a negative count from user error
        self.cr90Count = 0
        self.cr180Count = 0
        self.d556Count = 0
        self.d5240Count = 0
        self.d5m60Count = 0
        self.d5m120Count = 0
        self.nr56Count = 0
        self.nr240Count = 0
        self.re120Count = 0
        self.tr180Count = 0

        # Quantity box
        self.addLabel(text="Quantity", row=0, column=0)
        self.quantityField = self.addIntegerField(value="", row=1, column=0, sticky="NW")

        # The Add Menu Drop Down List
        nrc = self.addMenuBar(row=2, column=0)
        nrcOptions = nrc.addMenu("Add Products")
        nrcOptions.addMenuItem("CR-90", self.cr90)
        nrcOptions.addMenuItem("CR-180", self.cr180)
        nrcOptions.addMenuItem("D5-56", self.d556)
        nrcOptions.addMenuItem("D5-240", self.d5240)
        nrcOptions.addMenuItem("D5M-60", self.d5m60)
        nrcOptions.addMenuItem("D5M-120", self.d5m120)
        nrcOptions.addMenuItem("NR-56", self.nr56)
        nrcOptions.addMenuItem("NR-240", self.nr240)
        nrcOptions.addMenuItem("RE-120", self.re120)
        nrcOptions.addMenuItem("TR-180", self.tr180)

        # The Remove Menu Drop Down List
        nrcRemove = self.addMenuBar(row=3, column=0)
        nrcRemoveOptions = nrcRemove.addMenu("Remove Products")
        nrcRemoveOptions.addMenuItem("CR-90", self.cr90remove)
        nrcRemoveOptions.addMenuItem("CR-180", self.cr180remove)
        nrcRemoveOptions.addMenuItem("D5-56", self.d556remove)
        nrcRemoveOptions.addMenuItem("D5-240", self.d5240remove)
        nrcRemoveOptions.addMenuItem("D5M-60", self.d5m60remove)
        nrcRemoveOptions.addMenuItem("D5M-120", self.d5m120remove)
        nrcRemoveOptions.addMenuItem("NR-56", self.nr56remove)
        nrcRemoveOptions.addMenuItem("NR-240", self.nr240remove)
        nrcRemoveOptions.addMenuItem("RE-120", self.re120remove)
        nrcRemoveOptions.addMenuItem("TR-180", self.tr180remove)

        # Where output records are produced
        self.textArea = self.addTextArea(text="", row=0, column=1, rowspan=4, columnspan=3)

        # Place holders for general attributes about the package
        self.addLabel(text="Current Weight: ", row=5, column=0, sticky="NW")
        self.addLabel(text="Total Items: ", row=6, column=0, sticky="NW")
        self.addLabel(text="Package Size Needed: ", row=7, column=0, sticky="NW")
        self.addLabel(text="Package Unit Size: ", row=8, column=0, sticky="NW")
        self.addLabel(text="Current Item Unit Size: ", row=9, column=0, sticky="NW")

        # Buttons that clear the record or save the record
        self.addButton(text="Clear", row=10, column=0, rowspan=1, columnspan=1, command=self.clearData)
        self.addButton(text="Save Record", row=10, column=1, rowspan=1, columnspan=1, command=self.saveData)

        # Company Image for brand recognition
        self.imageLabel = self.addLabel(text="", row=5, column=2, rowspan=5, columnspan=1, sticky="NE")
        self.image1 = PhotoImage(file="logo.gif")
        self.imageLabel["image"] = self.image1

    def boxSize(self):  # Used to let the user know what size box they need for the current order
        if(self.packageSize == 0):
            packageString = self.packageDescription["zero"]
            self.addLabel(text=str(packageString), row=7, column=1, sticky="NW")
        elif(self.packageSize <= 6 and self.packageSize > 0):
            packageString = self.packageDescription["6pack"]
            self.addLabel(text=str(packageString), row=7, column=1, sticky="NW")
        elif(self.packageSize > 6 and self.packageSize <= 12):
            packageString = self.packageDescription["12pack"]
            self.addLabel(text=str(packageString), row=7, column=1, sticky="NW")
        elif (self.packageSize > 12 and self.packageSize <= 18):
            packageString = self.packageDescription["18pack"]
            self.addLabel(text=str(packageString), row=7, column=1, sticky="NW")
        elif (self.packageSize > 18 and self.packageSize <= 32):
            packageString = self.packageDescription["32pack"]
            self.addLabel(text=str(packageString), row=7, column=1, sticky="NW")
        else:  # Package Unit size is greater than 32
            packageString = self.packageDescription["overage"]
            self.addLabel(text=str(packageString), row=7, column=1, sticky="NW")
            self.textArea["state"] = "normal"
            self.textArea.appendText("***You're using " + str(self.packageSize) + " packing units. Max is 32 units.\n")
            self.textArea["state"] = "disabled"

    def clearData(self):  # Resets all data back to default - Extra spaces are to cover up old data in same location
        self.textArea["state"] = "normal"
        self.textArea.setText("")
        self.addLabel(text="0.0000 pounds     ", row=5, column=1, sticky="NW")
        self.addLabel(text="0     ", row=6, column=1, sticky="NW")
        self.addLabel(text="                                                           ", row=7, column=1, sticky="NW")
        self.addLabel(text="                                                           ", row=8, column=1, sticky="NW")
        self.addLabel(text="                                                           ", row=9, column=1, sticky="NW")
        self.weight = 0
        self.totalItems = 0
        self.packageSize = 0
        self.textLines = []
        self.quantityField = self.addIntegerField(value=0, row=1, column=0, sticky="NW")
        self.textArea["state"] = "disabled"

    def saveData(self):  # Saves input and output records of the text area - Doesn't record error messages
        recordKeeper = open("recordLog.txt", 'w')
        for index in range(len(self.textLines)):
            recordKeeper.write(str(self.textLines[index] + "\n"))
            self.textLines[-1] = self.textLines[-1].strip('\n')  # Removes blank lines that are added
            self.textLines[-1] = self.textLines[-1].strip('\n') # Removes blank lines that are added
        self.formatWeightForString = "%0.4f" % self.weight
        self.formatPackageSizeForString = "%0.4f" % self.packageSize
        recordKeeper.write("Weight: " + str(self.formatWeightForString) + " pounds\n")
        recordKeeper.write("Total Items: " + str(self.totalItems) + "\n")
        recordKeeper.write("Total Unit Size of Package: " + str(self.formatPackageSizeForString) + "\n")
        recordKeeper.write("Recorded on: " + str(datetime.now()))
        recordKeeper.close()

    def cr90(self):  # CysReplete 90 Capsules Bottles
        stringMask = "         "

        self.textArea["state"] = "normal"  # Enables the Text Area to be altered

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure no negative numbers are used. If a negative number is entered it's changed to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Changed to Zero\n")

        self.cr90Count += amount  # Keeps track of how many bottles of this category have been added
        self.weight += (0.505 * amount)  # Figures out how much weight to add based on item and quantity
        self.totalItems += amount  # Keeps track of total items
        self.packageSize += (self.unitSize["medium"] * amount)
        unitSpec = str(self.unitSize["medium"]) + str(stringMask)

        # The labels used to display data next to the category on the left
        self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
        self.addLabel(text=str(self.totalItems), row=6, column=1, sticky="NW")
        # boxSize method is the 7th row
        self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
        self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

        # Input for Text Area box
        self.textArea.appendText(str(amount) + " CysReplete 90 capsules added\n")
        self.textLines.append(str(amount) + " CysReplete 90 capsules added")
        self.textArea["state"] = "disabled"  # Turns on the Read Only for text area so user can't alter it
        self.boxSize()  # Checks for what box size should be used

    def cr90remove(self):
        self.textArea["state"] = "normal"  # Disables Read Only for Text Area
        stringMask = "          "  # Used to cover old data labels
        unitSpec = str(self.unitSize["medium"]) + str(stringMask)  # Used to display unit size on GUI

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure a negative number isn't entered and if so change it to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Change to Zero\n")

        validateData = self.cr90Count  # Used to confirm the correct amount of bottles gets removed
        self.cr90Count -= amount  # The raw amount of items based on user input
        if(self.cr90Count <= 0):  # Makes sure that if there is to many bottles removed that it's corrected
            self.packageSize -= (self.unitSize["medium"] * validateData)  # Only removes what is available
        else:
            self.packageSize -= (self.unitSize["medium"] * amount)  # The number of bottles that exist are confirmed

        if(self.cr90Count < 0):  # Corrects user error if trying to remove more bottles than what is added

            self.totalItems -= validateData  # validateData has the actual amount of bottles that has been enetered
            self.cr90Count = 0  # Resets bottle count to zero to prevent further user error
            self.textArea.appendText("***Error - Negative CysReplete 90 count - CR-90 set to zero\n")
            self.weight -= (0.505 * validateData)  # Removes only the actual weight that is available per bottles

            # Updates all the labels to the correct amount
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str(str("%0.4f" % self.packageSize) + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Displays the actual amount of item removed that is based on actual bottles added
            self.textArea.appendText(str(validateData) + " CysReplete 90 capsules removed\n")
            self.textLines.append(str(validateData) + " CysReplete 90 capsules removed")
            if(self.totalItems == 0):
                self.packageSize = 0
            self.boxSize()

        elif(self.packageSize <= 0):  # Resets the whole system if package size to zero since zero means nothing exists

            self.textArea.setText("")
            self.textArea.appendText("***Error - No Items Found\n")
            self.addLabel(text="0.0000 pounds     ", row=5, column=1, sticky="NW")
            self.addLabel(text="0     ", row=6, column=1, sticky="NW")
            self.addLabel(text="                                                           ", row=7, column=1, sticky="NW")
            self.weight = 0
            self.totalItems = 0
            self.packageSize = 0
            self.boxSize()
            self.textLines = []

            self.quantityField = self.addIntegerField(value=0, row=1, column=0, sticky="NW")

            self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            self.addLabel(text=str(str("0.0000") + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec) + str(stringMask), row=9, column=1, sticky="NW")

        else:

            self.weight -= (0.505 * amount)
            self.totalItems -= amount

            # Displays calculated fields
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Removes the requested amount since there is more bottles in the system than requested for removal
            self.textArea.appendText(str(amount) + " CysReplete 90 capsules removed\n")
            self.textLines.append(str(amount) + " CysReplete 90 capsules removed")

            self.boxSize()  # Runs boxSize method to know which box size to display
        self.textArea["state"] = "disabled"  # Makes the text area box read only again

    def cr180(self):  # CysReplete 180 Capsules Bottles
        stringMask = "         "

        self.textArea["state"] = "normal"  # Enables the Text Area to be altered

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure no negative numbers are used. If a negative number is entered it's changed to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Changed to Zero\n")

        self.cr180Count += amount  # Keeps track of how many bottles of this category have been added
        self.weight += (0.7625 * amount)  # Figures out how much weight to add based on item and quantity
        self.totalItems += amount  # Keeps track of total items
        self.packageSize += (self.unitSize["large"] * amount)
        unitSpec = str(self.unitSize["large"]) + str(stringMask)

        # The labels used to display data next to the category on the left
        self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
        self.addLabel(text=str(self.totalItems), row=6, column=1, sticky="NW")
        # boxSize method is the 7th row
        self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
        self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

        # Input for Text Area box
        self.textArea.appendText(str(amount) + " CysReplete 180 capsules added\n")
        self.textLines.append(str(amount) + " CysReplete 180 capsules added")
        self.textArea["state"] = "disabled"  # Turns on the Read Only for text area so user can't alter it
        self.boxSize()  # Checks for what box size should be used

    def cr180remove(self):
        self.textArea["state"] = "normal"  # Disables Read Only for Text Area
        stringMask = "          "  # Used to cover old data labels
        unitSpec = str(self.unitSize["large"]) + str(stringMask)  # Used to display unit size on GUI

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure a negative number isn't entered and if so change it to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Change to Zero\n")

        validateData = self.cr180Count  # Used to confirm the correct amount of bottles gets removed
        self.cr180Count -= amount  # The raw amount of items based on user input
        if(self.cr180Count <= 0):  # Makes sure that if there is to many bottles removed that it's corrected
            self.packageSize -= (self.unitSize["large"] * validateData)  # Only removes what is available
        else:
            self.packageSize -= (self.unitSize["large"] * amount)  # The number of bottles that exist are confirmed

        if(self.cr180Count < 0):  # Corrects user error if trying to remove more bottles than what is added

            self.totalItems -= validateData  # validateData has the actual amount of bottles that has been enetered
            self.cr180Count = 0  # Resets bottle count to zero to prevent further user error
            self.textArea.appendText("***Error - Negative CysReplete 90 count - CR-90 set to zero\n")
            self.weight -= (0.7625 * validateData)  # Removes only the actual weight that is available per bottles

            # Updates all the labels to the correct amount
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str(str("%0.4f" % self.packageSize) + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Displays the actual amount of item removed that is based on actual bottles added
            self.textArea.appendText(str(validateData) + " CysReplete 180 capsules removed\n")
            self.textLines.append(str(validateData) + " CysReplete 180 capsules removed")
            if(self.totalItems == 0):
                self.packageSize = 0
            self.boxSize()

        elif(self.packageSize <= 0):  # Resets the whole system if package size to zero since zero means nothing exists

            self.textArea.setText("")
            self.textArea.appendText("***Error - No Items Found\n")
            self.addLabel(text="0.0000 pounds     ", row=5, column=1, sticky="NW")
            self.addLabel(text="0     ", row=6, column=1, sticky="NW")
            self.addLabel(text="                                                           ", row=7, column=1, sticky="NW")
            self.weight = 0
            self.totalItems = 0
            self.packageSize = 0
            self.boxSize()
            self.textLines = []

            self.quantityField = self.addIntegerField(value=0, row=1, column=0, sticky="NW")

            self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            self.addLabel(text=str(str("0.0000") + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec) + str(stringMask), row=9, column=1, sticky="NW")

        else:

            self.weight -= (0.7625 * amount)
            self.totalItems -= amount

            # Displays calculated fields
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Removes the requested amount since there is more bottles in the system than requested for removal
            self.textArea.appendText(str(amount) + " CysReplete 180 capsules removed\n")
            self.textLines.append(str(amount) + " CysReplete 180 capsules removed")

            self.boxSize()  # Runs boxSize method to know which box size to display
        self.textArea["state"] = "disabled"  # Makes the text area box read only again

    def d556(self):  # D5 56 Capsules Bottles
        stringMask = "         "

        self.textArea["state"] = "normal"  # Enables the Text Area to be altered

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure no negative numbers are used. If a negative number is entered it's changed to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Changed to Zero\n")

        self.d556Count += amount  # Keeps track of how many bottles of this category have been added
        self.weight += (0.4312 * amount)  # Figures out how much weight to add based on item and quantity
        self.totalItems += amount  # Keeps track of total items
        self.packageSize += (self.unitSize["small"] * amount)
        unitSpec = str(self.unitSize["small"]) + str(stringMask)

        # The labels used to display data next to the category on the left
        self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
        self.addLabel(text=str(self.totalItems), row=6, column=1, sticky="NW")
        # boxSize method is the 7th row
        self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
        self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

        # Input for Text Area box
        self.textArea.appendText(str(amount) + " D5 56 capsules added\n")
        self.textLines.append(str(amount) + " D5 56 capsules added")
        self.textArea["state"] = "disabled"  # Turns on the Read Only for text area so user can't alter it
        self.boxSize()  # Checks for what box size should be used

    def d556remove(self):
        self.textArea["state"] = "normal"  # Disables Read Only for Text Area
        stringMask = "          "  # Used to cover old data labels
        unitSpec = str(self.unitSize["small"]) + str(stringMask)  # Used to display unit size on GUI

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure a negative number isn't entered and if so change it to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Change to Zero\n")

        validateData = self.d556Count  # Used to confirm the correct amount of bottles gets removed
        self.d556Count -= amount  # The raw amount of items based on user input
        if(self.d556Count <= 0):  # Makes sure that if there is to many bottles removed that it's corrected
            self.packageSize -= (self.unitSize["small"] * validateData)  # Only removes what is available
        else:
            self.packageSize -= (self.unitSize["small"] * amount)  # The number of bottles that exist are confirmed

        if(self.d556Count < 0):  # Corrects user error if trying to remove more bottles than what is added

            self.totalItems -= validateData  # validateData has the actual amount of bottles that has been enetered
            self.d556Count = 0  # Resets bottle count to zero to prevent further user error
            self.textArea.appendText("***Error - Negative CysReplete 90 count - CR-90 set to zero\n")
            self.weight -= (0.4312 * validateData)  # Removes only the actual weight that is available per bottles

            # Updates all the labels to the correct amount
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str(str("%0.4f" % self.packageSize) + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Displays the actual amount of item removed that is based on actual bottles added
            self.textArea.appendText(str(validateData) + " D5 56 capsules removed\n")
            self.textLines.append(str(validateData) + " D5 56 capsules removed")
            if(self.totalItems == 0):
                self.packageSize = 0
            self.boxSize()

        elif(self.packageSize <= 0):  # Resets the whole system if package size to zero since zero means nothing exists

            self.textArea.setText("")
            self.textArea.appendText("***Error - No Items Found\n")
            self.addLabel(text="0.0000 pounds     ", row=5, column=1, sticky="NW")
            self.addLabel(text="0     ", row=6, column=1, sticky="NW")
            self.addLabel(text="                                                           ", row=7, column=1, sticky="NW")
            self.weight = 0
            self.totalItems = 0
            self.packageSize = 0
            self.boxSize()
            self.textLines = []

            self.quantityField = self.addIntegerField(value=0, row=1, column=0, sticky="NW")

            self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            self.addLabel(text=str(str("0.0000") + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec) + str(stringMask), row=9, column=1, sticky="NW")

        else:

            self.weight -= (0.4312 * amount)
            self.totalItems -= amount

            # Displays calculated fields
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Removes the requested amount since there is more bottles in the system than requested for removal
            self.textArea.appendText(str(amount) + " D5 56 capsules removed\n")
            self.textLines.append(str(amount) + " D5 56 capsules removed")

            self.boxSize()  # Runs boxSize method to know which box size to display
        self.textArea["state"] = "disabled"  # Makes the text area box read only again

    def d5240(self):  # D5 240 Capsules Bottles
        stringMask = "         "

        self.textArea["state"] = "normal"  # Enables the Text Area to be altered

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure no negative numbers are used. If a negative number is entered it's changed to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Changed to Zero\n")

        self.d5240Count += amount  # Keeps track of how many bottles of this category have been added
        self.weight += (0.9125 * amount)  # Figures out how much weight to add based on item and quantity
        self.totalItems += amount  # Keeps track of total items
        self.packageSize += (self.unitSize["large"] * amount)
        unitSpec = str(self.unitSize["large"]) + str(stringMask)

        # The labels used to display data next to the category on the left
        self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
        self.addLabel(text=str(self.totalItems), row=6, column=1, sticky="NW")
        # boxSize method is the 7th row
        self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
        self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

        # Input for Text Area box
        self.textArea.appendText(str(amount) + " D5 240 capsules added\n")
        self.textLines.append(str(amount) + " D5 240 capsules added")
        self.textArea["state"] = "disabled"  # Turns on the Read Only for text area so user can't alter it
        self.boxSize()  # Checks for what box size should be used

    def d5240remove(self):
        self.textArea["state"] = "normal"  # Disables Read Only for Text Area
        stringMask = "          "  # Used to cover old data labels
        unitSpec = str(self.unitSize["large"]) + str(stringMask)  # Used to display unit size on GUI

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure a negative number isn't entered and if so change it to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Change to Zero\n")

        validateData = self.d5240Count  # Used to confirm the correct amount of bottles gets removed
        self.d5240Count -= amount  # The raw amount of items based on user input
        if(self.d5240Count <= 0):  # Makes sure that if there is to many bottles removed that it's corrected
            self.packageSize -= (self.unitSize["medium"] * validateData)  # Only removes what is available
        else:
            self.packageSize -= (self.unitSize["medium"] * amount)  # The number of bottles that exist are confirmed

        if(self.d5240Count < 0):  # Corrects user error if trying to remove more bottles than what is added

            self.totalItems -= validateData  # validateData has the actual amount of bottles that has been enetered
            self.d5240Count = 0  # Resets bottle count to zero to prevent further user error
            self.textArea.appendText("***Error - Negative CysReplete 90 count - CR-90 set to zero\n")
            self.weight -= (0.9125 * validateData)  # Removes only the actual weight that is available per bottles

            # Updates all the labels to the correct amount
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str(str("%0.4f" % self.packageSize) + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Displays the actual amount of item removed that is based on actual bottles added
            self.textArea.appendText(str(validateData) + " D5 240 capsules removed\n")
            self.textLines.append(str(validateData) + " D5 240 capsules removed")
            if(self.totalItems == 0):
                self.packageSize = 0
            self.boxSize()

        elif(self.packageSize <= 0):  # Resets the whole system if package size to zero since zero means nothing exists

            self.textArea.setText("")
            self.textArea.appendText("***Error - No Items Found\n")
            self.addLabel(text="0.0000 pounds     ", row=5, column=1, sticky="NW")
            self.addLabel(text="0     ", row=6, column=1, sticky="NW")
            self.addLabel(text="                                                           ", row=7, column=1, sticky="NW")
            self.weight = 0
            self.totalItems = 0
            self.packageSize = 0
            self.boxSize()
            self.textLines = []

            self.quantityField = self.addIntegerField(value=0, row=1, column=0, sticky="NW")

            self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            self.addLabel(text=str(str("0.0000") + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec) + str(stringMask), row=9, column=1, sticky="NW")

        else:

            self.weight -= (0.9125 * amount)
            self.totalItems -= amount

            # Displays calculated fields
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Removes the requested amount since there is more bottles in the system than requested for removal
            self.textArea.appendText(str(amount) + " D5 240 capsules removed\n")
            self.textLines.append(str(amount) + " D5 240 capsules removed")

            self.boxSize()  # Runs boxSize method to know which box size to display
        self.textArea["state"] = "disabled"  # Makes the text area box read only again

    def d5m60(self):  # D5 Mucuna 60 Capsules Bottles
        stringMask = "         "

        self.textArea["state"] = "normal"  # Enables the Text Area to be altered

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure no negative numbers are used. If a negative number is entered it's changed to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Changed to Zero\n")

        self.d5m60Count += amount  # Keeps track of how many bottles of this category have been added
        self.weight += (0.3875 * amount)  # Figures out how much weight to add based on item and quantity
        self.totalItems += amount  # Keeps track of total items
        self.packageSize += (self.unitSize["small"] * amount)
        unitSpec = str(self.unitSize["small"]) + str(stringMask)

        # The labels used to display data next to the category on the left
        self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
        self.addLabel(text=str(self.totalItems), row=6, column=1, sticky="NW")
        # boxSize method is the 7th row
        self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
        self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

        # Input for Text Area box
        self.textArea.appendText(str(amount) + " D5 Mucuna 60 capsules added\n")
        self.textLines.append(str(amount) + " D5 Mucuna 60 capsules added")
        self.textArea["state"] = "disabled"  # Turns on the Read Only for text area so user can't alter it
        self.boxSize()  # Checks for what box size should be used

    def d5m60remove(self):
        self.textArea["state"] = "normal"  # Disables Read Only for Text Area
        stringMask = "          "  # Used to cover old data labels
        unitSpec = str(self.unitSize["small"]) + str(stringMask)  # Used to display unit size on GUI

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure a negative number isn't entered and if so change it to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Change to Zero\n")

        validateData = self.d5m60Count  # Used to confirm the correct amount of bottles gets removed
        self.d5m60Count -= amount  # The raw amount of items based on user input
        if(self.d5m60Count <= 0):  # Makes sure that if there is to many bottles removed that it's corrected
            self.packageSize -= (self.unitSize["medium"] * validateData)  # Only removes what is available
        else:
            self.packageSize -= (self.unitSize["medium"] * amount)  # The number of bottles that exist are confirmed

        if(self.d5m60Count < 0):  # Corrects user error if trying to remove more bottles than what is added

            self.totalItems -= validateData  # validateData has the actual amount of bottles that has been enetered
            self.d5m60Count = 0  # Resets bottle count to zero to prevent further user error
            self.textArea.appendText("***Error - Negative CysReplete 90 count - CR-90 set to zero\n")
            self.weight -= (0.3875 * validateData)  # Removes only the actual weight that is available per bottles

            # Updates all the labels to the correct amount
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str(str("%0.4f" % self.packageSize) + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Displays the actual amount of item removed that is based on actual bottles added
            self.textArea.appendText(str(validateData) + " D5 Mucuna 60 capsules removed\n")
            self.textLines.append(str(validateData) + " D5 Mucuna 60 capsules removed")
            if(self.totalItems == 0):
                self.packageSize = 0
            self.boxSize()

        elif(self.packageSize <= 0):  # Resets the whole system if package size to zero since zero means nothing exists

            self.textArea.setText("")
            self.textArea.appendText("***Error - No Items Found\n")
            self.addLabel(text="0.0000 pounds     ", row=5, column=1, sticky="NW")
            self.addLabel(text="0     ", row=6, column=1, sticky="NW")
            self.addLabel(text="                                                           ", row=7, column=1, sticky="NW")
            self.weight = 0
            self.totalItems = 0
            self.packageSize = 0
            self.boxSize()
            self.textLines = []

            self.quantityField = self.addIntegerField(value=0, row=1, column=0, sticky="NW")

            self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            self.addLabel(text=str(str("0.0000") + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec) + str(stringMask), row=9, column=1, sticky="NW")

        else:

            self.weight -= (0.3875 * amount)
            self.totalItems -= amount

            # Displays calculated fields
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Removes the requested amount since there is more bottles in the system than requested for removal
            self.textArea.appendText(str(amount) + " D5 Mucuna 60 capsules removed\n")
            self.textLines.append(str(amount) + " D5 Mucuna 60 capsules removed")

            self.boxSize()  # Runs boxSize method to know which box size to display
        self.textArea["state"] = "disabled"  # Makes the text area box read only again

    def d5m120(self):  # D5 Mucuna 120 Capsules Bottles
        stringMask = "         "

        self.textArea["state"] = "normal"  # Enables the Text Area to be altered

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure no negative numbers are used. If a negative number is entered it's changed to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Changed to Zero\n")

        self.d5m120Count += amount  # Keeps track of how many bottles of this category have been added
        self.weight += (0.5 * amount)  # Figures out how much weight to add based on item and quantity
        self.totalItems += amount  # Keeps track of total items
        self.packageSize += (self.unitSize["medium"] * amount)
        unitSpec = str(self.unitSize["medium"]) + str(stringMask)

        # The labels used to display data next to the category on the left
        self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
        self.addLabel(text=str(self.totalItems), row=6, column=1, sticky="NW")
        # boxSize method is the 7th row
        self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
        self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

        # Input for Text Area box
        self.textArea.appendText(str(amount) + " D5 Mucuna 120 capsules added\n")
        self.textLines.append(str(amount) + " D5 Mucuna 120 capsules added")
        self.textArea["state"] = "disabled"  # Turns on the Read Only for text area so user can't alter it
        self.boxSize()  # Checks for what box size should be used

    def d5m120remove(self):
        self.textArea["state"] = "normal"  # Disables Read Only for Text Area
        stringMask = "          "  # Used to cover old data labels
        unitSpec = str(self.unitSize["small"]) + str(stringMask)  # Used to display unit size on GUI

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure a negative number isn't entered and if so change it to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Change to Zero\n")

        validateData = self.d5m120Count  # Used to confirm the correct amount of bottles gets removed
        self.d5m120Count -= amount  # The raw amount of items based on user input
        if(self.d5m120Count <= 0):  # Makes sure that if there is to many bottles removed that it's corrected
            self.packageSize -= (self.unitSize["medium"] * validateData)  # Only removes what is available
        else:
            self.packageSize -= (self.unitSize["medium"] * amount)  # The number of bottles that exist are confirmed

        if(self.d5m120Count < 0):  # Corrects user error if trying to remove more bottles than what is added

            self.totalItems -= validateData  # validateData has the actual amount of bottles that has been enetered
            self.d5m120Count = 0  # Resets bottle count to zero to prevent further user error
            self.textArea.appendText("***Error - Negative CysReplete 90 count - CR-90 set to zero\n")
            self.weight -= (0.5 * validateData)  # Removes only the actual weight that is available per bottles

            # Updates all the labels to the correct amount
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str(str("%0.4f" % self.packageSize) + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Displays the actual amount of item removed that is based on actual bottles added
            self.textArea.appendText(str(validateData) + " D5 Mucuna 120 capsules removed\n")
            self.textLines.append(str(validateData) + " D5 Mucuna 120 capsules removed")
            if(self.totalItems == 0):
                self.packageSize = 0
            self.boxSize()

        elif(self.packageSize <= 0):  # Resets the whole system if package size to zero since zero means nothing exists

            self.textArea.setText("")
            self.textArea.appendText("***Error - No Items Found\n")
            self.addLabel(text="0.0000 pounds     ", row=5, column=1, sticky="NW")
            self.addLabel(text="0     ", row=6, column=1, sticky="NW")
            self.addLabel(text="                                                           ", row=7, column=1, sticky="NW")
            self.weight = 0
            self.totalItems = 0
            self.packageSize = 0
            self.boxSize()
            self.textLines = []

            self.quantityField = self.addIntegerField(value=0, row=1, column=0, sticky="NW")

            self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            self.addLabel(text=str(str("0.0000") + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec) + str(stringMask), row=9, column=1, sticky="NW")

        else:

            self.weight -= (0.5 * amount)
            self.totalItems -= amount

            # Displays calculated fields
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Removes the requested amount since there is more bottles in the system than requested for removal
            self.textArea.appendText(str(amount) + " D5 Mucuna 120 capsules removed\n")
            self.textLines.append(str(amount) + " D5 Mucuna 120 capsules capsules removed")

            self.boxSize()  # Runs boxSize method to know which box size to display
        self.textArea["state"] = "disabled"  # Makes the text area box read only again

    def nr56(self):  # NeuroReplete 56 Capsules Bottles
        stringMask = "         "

        self.textArea["state"] = "normal"  # Enables the Text Area to be altered

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure no negative numbers are used. If a negative number is entered it's changed to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Changed to Zero\n")

        self.nr56Count += amount  # Keeps track of how many bottles of this category have been added
        self.weight += (0.4312 * amount)  # Figures out how much weight to add based on item and quantity
        self.totalItems += amount  # Keeps track of total items
        self.packageSize += (self.unitSize["small"] * amount)
        unitSpec = str(self.unitSize["small"]) + str(stringMask)

        # The labels used to display data next to the category on the left
        self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
        self.addLabel(text=str(self.totalItems), row=6, column=1, sticky="NW")
        # boxSize method is the 7th row
        self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
        self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

        # Input for Text Area box
        self.textArea.appendText(str(amount) + " NeuroReplete 56 capsules added\n")
        self.textLines.append(str(amount) + " NeuroReplete 56 capsules added")
        self.textArea["state"] = "disabled"  # Turns on the Read Only for text area so user can't alter it
        self.boxSize()  # Checks for what box size should be used

    def nr56remove(self):
        self.textArea["state"] = "normal"  # Disables Read Only for Text Area
        stringMask = "          "  # Used to cover old data labels
        unitSpec = str(self.unitSize["small"]) + str(stringMask)  # Used to display unit size on GUI

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure a negative number isn't entered and if so change it to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Change to Zero\n")

        validateData = self.nr56Count  # Used to confirm the correct amount of bottles gets removed
        self.nr56Count -= amount  # The raw amount of items based on user input
        if(self.nr56Count <= 0):  # Makes sure that if there is to many bottles removed that it's corrected
            self.packageSize -= (self.unitSize["medium"] * validateData)  # Only removes what is available
        else:
            self.packageSize -= (self.unitSize["medium"] * amount)  # The number of bottles that exist are confirmed

        if(self.nr56Count < 0):  # Corrects user error if trying to remove more bottles than what is added

            self.totalItems -= validateData  # validateData has the actual amount of bottles that has been enetered
            self.nr56Count = 0  # Resets bottle count to zero to prevent further user error
            self.textArea.appendText("***Error - Negative CysReplete 90 count - CR-90 set to zero\n")
            self.weight -= (0.4312 * validateData)  # Removes only the actual weight that is available per bottles

            # Updates all the labels to the correct amount
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str(str("%0.4f" % self.packageSize) + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Displays the actual amount of item removed that is based on actual bottles added
            self.textArea.appendText(str(validateData) + " NeuroReplete 56 capsules removed\n")
            self.textLines.append(str(validateData) + " NeuroReplete 56 capsules removed")
            if(self.totalItems == 0):
                self.packageSize = 0
            self.boxSize()

        elif(self.packageSize <= 0):  # Resets the whole system if package size to zero since zero means nothing exists

            self.textArea.setText("")
            self.textArea.appendText("***Error - No Items Found\n")
            self.addLabel(text="0.0000 pounds     ", row=5, column=1, sticky="NW")
            self.addLabel(text="0     ", row=6, column=1, sticky="NW")
            self.addLabel(text="                                                           ", row=7, column=1, sticky="NW")
            self.weight = 0
            self.totalItems = 0
            self.packageSize = 0
            self.boxSize()
            self.textLines = []

            self.quantityField = self.addIntegerField(value=0, row=1, column=0, sticky="NW")

            self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            self.addLabel(text=str(str("0.0000") + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec) + str(stringMask), row=9, column=1, sticky="NW")

        else:

            self.weight -= (0.4312 * amount)
            self.totalItems -= amount

            # Displays calculated fields
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Removes the requested amount since there is more bottles in the system than requested for removal
            self.textArea.appendText(str(amount) + " NeuroReplete 56 capsules removed\n")
            self.textLines.append(str(amount) + " NeuroReplete 56 capsules removed")

            self.boxSize()  # Runs boxSize method to know which box size to display
        self.textArea["state"] = "disabled"  # Makes the text area box read only again

    def nr240(self):  # NeuroReplete 240 Capsules Bottles
        stringMask = "         "

        self.textArea["state"] = "normal"  # Enables the Text Area to be altered

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure no negative numbers are used. If a negative number is entered it's changed to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Changed to Zero\n")

        self.nr240Count += amount  # Keeps track of how many bottles of this category have been added
        self.weight += (0.9 * amount)  # Figures out how much weight to add based on item and quantity
        self.totalItems += amount  # Keeps track of total items
        self.packageSize += (self.unitSize["large"] * amount)
        unitSpec = str(self.unitSize["large"]) + str(stringMask)

        # The labels used to display data next to the category on the left
        self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
        self.addLabel(text=str(self.totalItems), row=6, column=1, sticky="NW")
        # boxSize method is the 7th row
        self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
        self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

        # Input for Text Area box
        self.textArea.appendText(str(amount) + " NeuroReplete 240 capsules added\n")
        self.textLines.append(str(amount) + " NeuroReplete 240 capsules added")
        self.textArea["state"] = "disabled"  # Turns on the Read Only for text area so user can't alter it
        self.boxSize()  # Checks for what box size should be used

    def nr240remove(self):
        self.textArea["state"] = "normal"  # Disables Read Only for Text Area
        stringMask = "          "  # Used to cover old data labels
        unitSpec = str(self.unitSize["large"]) + str(stringMask)  # Used to display unit size on GUI

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure a negative number isn't entered and if so change it to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Change to Zero\n")

        validateData = self.nr240Count  # Used to confirm the correct amount of bottles gets removed
        self.nr240Count -= amount  # The raw amount of items based on user input
        if(self.nr240Count <= 0):  # Makes sure that if there is to many bottles removed that it's corrected
            self.packageSize -= (self.unitSize["large"] * validateData)  # Only removes what is available
        else:
            self.packageSize -= (self.unitSize["large"] * amount)  # The number of bottles that exist are confirmed

        if(self.nr240Count < 0):  # Corrects user error if trying to remove more bottles than what is added

            self.totalItems -= validateData  # validateData has the actual amount of bottles that has been enetered
            self.nr240Count = 0  # Resets bottle count to zero to prevent further user error
            self.textArea.appendText("***Error - Negative CysReplete 90 count - CR-90 set to zero\n")
            self.weight -= (0.9 * validateData)  # Removes only the actual weight that is available per bottles

            # Updates all the labels to the correct amount
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str(str("%0.4f" % self.packageSize) + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Displays the actual amount of item removed that is based on actual bottles added
            self.textArea.appendText(str(validateData) + " NeuroReplete 240 capsules removed\n")
            self.textLines.append(str(validateData) + " NeuroReplete 240 capsules removed")
            if(self.totalItems == 0):
                self.packageSize = 0
            self.boxSize()

        elif(self.packageSize <= 0):  # Resets the whole system if package size to zero since zero means nothing exists

            self.textArea.setText("")
            self.textArea.appendText("***Error - No Items Found\n")
            self.addLabel(text="0.0000 pounds     ", row=5, column=1, sticky="NW")
            self.addLabel(text="0     ", row=6, column=1, sticky="NW")
            self.addLabel(text="                                                           ", row=7, column=1, sticky="NW")
            self.weight = 0
            self.totalItems = 0
            self.packageSize = 0
            self.boxSize()
            self.textLines = []

            self.quantityField = self.addIntegerField(value=0, row=1, column=0, sticky="NW")

            self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            self.addLabel(text=str(str("0.0000") + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec) + str(stringMask), row=9, column=1, sticky="NW")

        else:

            self.weight -= (0.9 * amount)
            self.totalItems -= amount

            # Displays calculated fields
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Removes the requested amount since there is more bottles in the system than requested for removal
            self.textArea.appendText(str(amount) + " NeuroReplete 240 capsules removed\n")
            self.textLines.append(str(amount) + " NeuroReplete 240 capsules removed")

            self.boxSize()  # Runs boxSize method to know which box size to display
        self.textArea["state"] = "disabled"  # Makes the text area box read only again

    def re120(self):  # Replete Extra 120 Capsules Bottles
        stringMask = "         "

        self.textArea["state"] = "normal"  # Enables the Text Area to be altered

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure no negative numbers are used. If a negative number is entered it's changed to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Changed to Zero\n")

        self.re120Count += amount  # Keeps track of how many bottles of this category have been added
        self.weight += (0.4687 * amount)  # Figures out how much weight to add based on item and quantity
        self.totalItems += amount  # Keeps track of total items
        self.packageSize += (self.unitSize["medium"] * amount)
        unitSpec = str(self.unitSize["medium"]) + str(stringMask)

        # The labels used to display data next to the category on the left
        self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
        self.addLabel(text=str(self.totalItems), row=6, column=1, sticky="NW")
        # boxSize method is the 7th row
        self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
        self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

        # Input for Text Area box
        self.textArea.appendText(str(amount) + " Replete Extra 120 capsules added\n")
        self.textLines.append(str(amount) + " Replete Extra 120 capsules added")
        self.textArea["state"] = "disabled"  # Turns on the Read Only for text area so user can't alter it
        self.boxSize()  # Checks for what box size should be used

    def re120remove(self):
        self.textArea["state"] = "normal"  # Disables Read Only for Text Area
        stringMask = "          "  # Used to cover old data labels
        unitSpec = str(self.unitSize["medium"]) + str(stringMask)  # Used to display unit size on GUI

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure a negative number isn't entered and if so change it to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Change to Zero\n")

        validateData = self.re120Count  # Used to confirm the correct amount of bottles gets removed
        self.re120Count -= amount  # The raw amount of items based on user input
        if(self.re120Count <= 0):  # Makes sure that if there is to many bottles removed that it's corrected
            self.packageSize -= (self.unitSize["medium"] * validateData)  # Only removes what is available
        else:
            self.packageSize -= (self.unitSize["medium"] * amount)  # The number of bottles that exist are confirmed

        if(self.re120Count < 0):  # Corrects user error if trying to remove more bottles than what is added

            self.totalItems -= validateData  # validateData has the actual amount of bottles that has been enetered
            self.re120Count = 0  # Resets bottle count to zero to prevent further user error
            self.textArea.appendText("***Error - Negative CysReplete 90 count - CR-90 set to zero\n")
            self.weight -= (0.4687 * validateData)  # Removes only the actual weight that is available per bottles

            # Updates all the labels to the correct amount
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str(str("%0.4f" % self.packageSize) + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Displays the actual amount of item removed that is based on actual bottles added
            self.textArea.appendText(str(validateData) + " Replete Extra 120 capsules removed\n")
            self.textLines.append(str(validateData) + " Replete Extra 120 capsules removed")
            if(self.totalItems == 0):
                self.packageSize = 0
            self.boxSize()

        elif(self.packageSize <= 0):  # Resets the whole system if package size to zero since zero means nothing exists

            self.textArea.setText("")
            self.textArea.appendText("***Error - No Items Found\n")
            self.addLabel(text="0.0000 pounds     ", row=5, column=1, sticky="NW")
            self.addLabel(text="0     ", row=6, column=1, sticky="NW")
            self.addLabel(text="                                                           ", row=7, column=1, sticky="NW")
            self.weight = 0
            self.totalItems = 0
            self.packageSize = 0
            self.boxSize()
            self.textLines = []

            self.quantityField = self.addIntegerField(value=0, row=1, column=0, sticky="NW")

            self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            self.addLabel(text=str(str("0.0000") + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec) + str(stringMask), row=9, column=1, sticky="NW")

        else:

            self.weight -= (0.4687 * amount)
            self.totalItems -= amount

            # Displays calculated fields
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Removes the requested amount since there is more bottles in the system than requested for removal
            self.textArea.appendText(str(amount) + " Replete Extra 120 capsules removed\n")
            self.textLines.append(str(amount) + " Replete Extra 120 capsules removed")

            self.boxSize()  # Runs boxSize method to know which box size to display
        self.textArea["state"] = "disabled"  # Makes the text area box read only again

    def tr180(self):  # Tyrosine Replete 180 Capsules Bottles
        stringMask = "         "

        self.textArea["state"] = "normal"  # Enables the Text Area to be altered

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure no negative numbers are used. If a negative number is entered it's changed to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Changed to Zero\n")

        self.tr180Count += amount  # Keeps track of how many bottles of this category have been added
        self.weight += (0.6 * amount)  # Figures out how much weight to add based on item and quantity
        self.totalItems += amount  # Keeps track of total items
        self.packageSize += (self.unitSize["medium"] * amount)
        unitSpec = str(self.unitSize["medium"]) + str(stringMask)

        # The labels used to display data next to the category on the left
        self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
        self.addLabel(text=str(self.totalItems), row=6, column=1, sticky="NW")
        # boxSize method is the 7th row
        self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
        self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

        # Input for Text Area box
        self.textArea.appendText(str(amount) + " Tyrosine Replete 180 capsules added\n")
        self.textLines.append(str(amount) + " Tyrosine Replete 180 capsules added")
        self.textArea["state"] = "disabled"  # Turns on the Read Only for text area so user can't alter it
        self.boxSize()  # Checks for what box size should be used

    def tr180remove(self):
        self.textArea["state"] = "normal"  # Disables Read Only for Text Area
        stringMask = "          "  # Used to cover old data labels
        unitSpec = str(self.unitSize["medium"]) + str(stringMask)  # Used to display unit size on GUI

        try:  # Test to make sure an integer is entered
            amount = int(self.quantityField.getNumber())
        except ValueError:
            self.textArea.appendText("***Error - Please Enter a whole number\n")

        if(amount < 0):  # Makes sure a negative number isn't entered and if so change it to zero
            amount = 0
            self.textArea.appendText("***Error - Negative Number Change to Zero\n")

        validateData = self.tr180Count  # Used to confirm the correct amount of bottles gets removed
        self.tr180Count -= amount  # The raw amount of items based on user input
        if(self.tr180Count <= 0):  # Makes sure that if there is to many bottles removed that it's corrected
            self.packageSize -= (self.unitSize["medium"] * validateData)  # Only removes what is available
        else:
            self.packageSize -= (self.unitSize["medium"] * amount)  # The number of bottles that exist are confirmed

        if(self.tr180Count < 0):  # Corrects user error if trying to remove more bottles than what is added

            self.totalItems -= validateData  # validateData has the actual amount of bottles that has been enetered
            self.tr180Count = 0  # Resets bottle count to zero to prevent further user error
            self.textArea.appendText("***Error - Negative CysReplete 90 count - CR-90 set to zero\n")
            self.weight -= (0.6 * validateData)  # Removes only the actual weight that is available per bottles

            # Updates all the labels to the correct amount
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str(str("%0.4f" % self.packageSize) + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Displays the actual amount of item removed that is based on actual bottles added
            self.textArea.appendText(str(validateData) + " Tyrosine Replete 180 capsules removed\n")
            self.textLines.append(str(validateData) + " Tyrosine Replete 180 capsules removed")
            if(self.totalItems == 0):
                self.packageSize = 0
            self.boxSize()

        elif(self.packageSize <= 0):  # Resets the whole system if package size to zero since zero means nothing exists

            self.textArea.setText("")
            self.textArea.appendText("***Error - No Items Found\n")
            self.addLabel(text="0.0000 pounds     ", row=5, column=1, sticky="NW")
            self.addLabel(text="0     ", row=6, column=1, sticky="NW")
            self.addLabel(text="                                                           ", row=7, column=1, sticky="NW")
            self.weight = 0
            self.totalItems = 0
            self.packageSize = 0
            self.boxSize()
            self.textLines = []

            self.quantityField = self.addIntegerField(value=0, row=1, column=0, sticky="NW")

            self.addLabel(text=str("%0.4f" % self.weight + " pounds"), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            self.addLabel(text=str(str("0.0000") + str(stringMask)), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec) + str(stringMask), row=9, column=1, sticky="NW")

        else:

            self.weight -= (0.6 * amount)
            self.totalItems -= amount

            # Displays calculated fields
            self.addLabel(text=str("%0.4f" % self.weight + " pounds   "), row=5, column=1, sticky="NW")
            self.addLabel(text=str(str(self.totalItems) + str(stringMask)), row=6, column=1, sticky="NW")
            # boxSize method is the 7th row
            self.addLabel(text=str("%0.4f" % self.packageSize), row=8, column=1, sticky="NW")
            self.addLabel(text=str(unitSpec), row=9, column=1, sticky="NW")

            # Removes the requested amount since there is more bottles in the system than requested for removal
            self.textArea.appendText(str(amount) + " Tyrosine Replete 180 capsules removed\n")
            self.textLines.append(str(amount) + " Tyrosine Replete 180 capsules removed")

            self.boxSize()  # Runs boxSize method to know which box size to display
        self.textArea["state"] = "disabled"  # Makes the text area box read only again


def main():
    Calculator().mainloop()


if __name__ == "__main__":
    main()
