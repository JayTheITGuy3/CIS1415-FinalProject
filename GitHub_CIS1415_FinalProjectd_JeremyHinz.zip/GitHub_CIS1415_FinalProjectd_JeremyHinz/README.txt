Bottle Weight & Shipping Calculator
Created by Jeremy Hinz
Creation Date: November 30, 2020

--------------------------------------------------
To Add Items
To start, enter the number of bottles you want to add.
Next, click Add Products and select the code.
The amount in the quantity box is how many of the bottle selected will be added.

-------------------------------------------------
To Remove Items
Enter the quantity that you want to remove.
Next click the Remove Products button and select the item you want to remove.

-------------------------------------------------
GUI - Side Notes
As you add items, the following keeps track of data.
Current Weight: is the correct weight of the box in pounds.
Total Items: Is how many items are in the order.
Package Needed: Is what size box that you need. If you go over 32 storage units you will have to split the order into more boxes.
Package unit size shows how much storage unit space is needed for the items.
The Current Item Unit Size is how many unit space each individual bottle uses that is selected.

-------------------------------------------------

Controls
Clear - Clears all data and reset all variables to zero
Save Record - Saves the current order in a text file in the same directory as the program

-------------------------------------------------
Validation
If the item isn't on the list or used a quantity more then available it will zero out the item and return an error.

Each item has it's own counter to make sure there is never a negative number for any of the individual products.

There are several validations in place to make sure items exist that are being removed. Plus make sure the packing is never negative.

The quantity box has a try except attached to it to make sure only integer numbers can be added. After that is a if statement to check to make sure the quantity is a positive number.